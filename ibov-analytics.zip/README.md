# IBOV Analytics

Projeto para análise de ações do IBOV usando Python e IA.